<template>
    <div class="input-group">

        <input
            v-model="searchTerm"
            class="form-control"
            placeholder="Search products..."
            type="search"
            @input="onInput"
        >

        <div
            class="input-group-append"
            v-show="searchTerm !== ''"
            @click="eraseSearchTerm"
        >
            <button class="btn btn-outline-secondary">
                X
            </button>
        </div>
    </div>
</template>

<script>
export default {
    name: 'SearchBar',
    data() {
        return {
            searchTerm: '',
            searchTimeout: null,
        };
    },
    methods: {
        /**
         * Resets the search term
         */
        eraseSearchTerm() {
            this.searchTerm = '';
            this.$emit('search-products', { term: this.searchTerm });
        },

        /**
         * Handles input changes
         */
        onInput() {
            if (this.searchTimeout !== null) {
                window.clearTimeout(this.searchTimeout);
                this.searchTimeout = null;
            }

            this.searchTimeout = window.setTimeout(() => {
                this.$emit('search-products', { term: this.searchTerm });
            }, 200);
        },
    },
};
</script>
