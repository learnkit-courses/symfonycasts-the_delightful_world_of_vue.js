/**
 * Generates the params for the URL to call for a list of products
 * by category or search term
 *
 * @param {string|null} category
 * @param {string} searchTerm
 * @return {object}
 */
export default (category, searchTerm) => {
    const params = {};

    if (category) {
        params.category = category;
    }

    if (searchTerm !== '') {
        params.name = searchTerm;
    }

    return params;
};
