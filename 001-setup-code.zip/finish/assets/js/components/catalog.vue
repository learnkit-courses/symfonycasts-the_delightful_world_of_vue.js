<template>
    <div>
        <div class="row">
            <div class="col-3">
                <title-component
                    :current-category-id="currentCategoryId"
                    :categories="categories"
                />
            </div>
            <div class="col-9">
                <search-bar @search-products="onSearchProducts" />
            </div>
        </div>

        <product-list
            :products="products"
            :loading="loading"
        />

        <div class="row">
            <legend-component :title="legend" />
        </div>
    </div>
</template>

<script>
import { fetchProducts } from '@/services/products-service';
import LegendComponent from '@/components/legend';
import ProductList from '@/components/product-list';
import SearchBar from '@/components/search-bar';
import TitleComponent from '@/components/title';

export default {
    name: 'Catalog',
    components: {
        LegendComponent,
        ProductList,
        SearchBar,
        TitleComponent,
    },
    props: {
        currentCategoryId: {
            type: String,
            default: null,
        },
        categories: {
            type: Array,
            required: true,
        },
    },
    data() {
        return {
            /** @type {Product[]} */
            products: [],
            loading: true,
            legend: 'Shipping takes 10-13 weeks, and products probably won\'t work',
        };
    },
    created() {
        this.getProducts('');
    },
    methods: {
        /**
         * Handles a change in the searchTerm provided by the search bar and fetches new products
         *
         * @param {string} term
         */
        onSearchProducts({ term }) {
            this.getProducts(term);
        },

        /**
         * Fetches products from the API
         *
         * @param {string} searchTerm
         */
        async getProducts(searchTerm) {
            this.products = [];
            this.loading = true;

            try {
                const response = await fetchProducts(this.currentCategoryId, searchTerm);

                this.loading = false;
                this.products = response.data['hydra:member'];
            } catch (e) {
                this.loading = false;
            }
        },
    },
};
</script>
