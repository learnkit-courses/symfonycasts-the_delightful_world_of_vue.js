import Vue from 'vue';
import App from '@/pages/products';

new Vue({
    render: (h) => h(App, {
        props: {
            currentCategoryId: window.currentCategoryId,
            categories: window.categories,
        },
    }),
}).$mount('#app');
