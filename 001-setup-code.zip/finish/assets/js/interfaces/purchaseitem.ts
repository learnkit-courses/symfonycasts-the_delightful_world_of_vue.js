export interface PurchaseItem {
  '@id'?: string;
  purchase?: string;
  product?: string;
  color?: string;
  quantity?: number;
  id?: string;
}
